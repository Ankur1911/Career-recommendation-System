import { Link } from "react-router-dom";
import a from "../Image/profile_back.png";
import b from "../Image/profile.jpg";
import axios from "axios";
import "../Components/Main.css";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";

export default function Main() {
  const [name, setData] = useState({
    name: "asdfewf",
  });
  const [mail,setMail] = useState({
    email: "",
  })
  useEffect(() => {
    const getAds = async () => {
      const res = await axios.get("http://localhost:8080/api/users");
      setData(res.data.data[0].firstName);
      console.log(res.data.data[0].firstName);
    };
    getAds();
  }, [setData]);
  axios.get("http://localhost:8080/api/users").then(function (response) {});

  return (
    <div className="main">
      <div className="nav">
        <div className="nav--upper">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="33"
            height="33"
            fill="currentColor"
            class="bi bi-house-door"
            viewBox="0 0 16 16"
          >
            <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5z" />
          </svg>
        </div>

        <div className="nav--lower">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="33"
            height="33"
            fill="currentColor"
            class="bi bi-chat"
            viewBox="0 0 16 16"
          >
            <path d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z" />
          </svg>
          <br />
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="33"
            height="33"
            fill="currentColor"
            class="bi bi-person-circle"
            viewBox="0 0 16 16"
          >
            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
            <path
              fill-rule="evenodd"
              d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"
            />
          </svg>
        </div>
      </div>

      <div className="content">
        <img src={a} className="image-background" alt=""></img>
        <img src={b} className="image" alt="" />
        <h1 className="content--name">{name.name}</h1>
        <span className="content--mail">20dce110@charusat.edu.in</span>
        <hr style={{ width: "1245px" }} />
        <a className="btn-editProfile2" href="/editprofile">
          Edit Profile
        </a>
      </div>
    </div>
  );
}
